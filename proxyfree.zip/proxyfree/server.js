const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");
const app = express();
const PORT = 3000;

app.use(express.static("public"));

app.use("/proxy", (req, res, next) => {
  const targetUrl = req.query.url;
  if (!targetUrl) {
    res.status(400).send("URL is required");
    return;
  }

  createProxyMiddleware({
    target: targetUrl,
    changeOrigin: true,
    pathRewrite: { '^/proxy': '' },
    secure: false,
    ws: true,
    onError: (err, req, res) => {
      res.status(500).send("Proxy error: " + err.message);
    },
  })(req, res, next);
});

// Listen ke semua interface supaya bisa diakses dari luar
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running at http://localhost:${PORT} and accessible via IP on port ${PORT}`);
});
